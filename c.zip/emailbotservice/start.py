import os
import asyncio
import argparse
from emailbotservice.service import EmailBotService


DEFAULT_ATTACHMENT_DIRECTORY = "attachments"
DEFAULT_PICKLES_DIRECTORY = "pickles"
DEFAULT_BOT_INTERVAL = 5 * 60
DEFAULT_DB_FILE = "botservice_status.json"


if __name__ == '__main__':

    import sys; sys.argv += ["-f", "config.json"] # For Debugging

    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--file', default=None)
    args = parser.parse_args()

    if not args.file:
        print("Config file not specified. Will stop")
    elif not os.path.isfile(args.file):
        print("Config file doesn't exits. Will stop")
    else:
        loop = asyncio.get_event_loop()
        EmailBotService(
            loop,
            interval=DEFAULT_BOT_INTERVAL,
            db_file=DEFAULT_DB_FILE,
            attachment_directory=DEFAULT_ATTACHMENT_DIRECTORY,
            pickles_directory=DEFAULT_PICKLES_DIRECTORY,
        ).run(args.file)
