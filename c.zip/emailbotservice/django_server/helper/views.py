import sys
from helper.graph_helper import *

from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from datetime import datetime, timedelta

from dateutil import tz, parser
from helper.auth_helper import get_sign_in_flow, get_token_from_code, store_user, remove_user_and_token, get_token


import time
import socket
import threading

LOCAL_SERVER_PORT = 9876


def home(request):
  context = initialize_context(request)
  return render(request, 'helper/home.html', context)


def initialize_context(request):
  context = {}

  # Check for any errors in the session
  error = request.session.pop('flash_error', None)

  if error != None:
    context['errors'] = []
    context['errors'].append(error)

  # Check for user in the session
  context['user'] = request.session.get('user', {'is_authenticated': False})
  return context


def sign_in(request):
      # Get the sign-in flow
  flow = get_sign_in_flow()
  # Save the expected flow so we can use it in the callback
  try:
    request.session['auth_flow'] = flow
  except Exception as e:
    print(e)
  # Redirect to the Azure sign-in page
  val = HttpResponseRedirect(flow['auth_uri'])
  return val


def forwarder_thread(data):

      print("Thread started")

      while True:
        try:
          clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
          clientSocket.settimeout(10)
          clientSocket.connect(("127.0.0.1", LOCAL_SERVER_PORT))
          clientSocket.send(data.encode())
          print("Thread sent data:", data)

          try:
              data = clientSocket.recv(100)
              if data:
                  data = data.decode()
                  if data == 'ok':
                        print("Thread got response. Stopping")
                        break
          except:
              pass


          clientSocket.close()
          time.sleep(5)
        except Exception as e:
          print("Thread exception:", e)
          time.sleep(5)




def get_mail_test(token_value):
    graph_url = 'https://graph.microsoft.com/v1.0'
    mails = requests.get(
        '{0}/me/mailfolders/inbox/messages'.format(graph_url),
        headers={
        'Authorization': 'Bearer {0}'.format(token_value)
        },
        params={
        '$top': '1'
        })
    return mails.json()


def callback(request):
  # Make the token request
  print("Django: Callback")
  result = get_token_from_code(request)

  #Get the user's profile
  user = get_user(result['access_token'])
  # mails = get_mails(result['access_token'])

  # Store user
  store_user(request, user)
  data = result['access_token']
  print("Django: Data:", data)

  print("\n" * 10)
  print("Token:", type(data), data)
  print("\n" * 10)

  mails = get_mail_test(data)
  print("Mails:",  mails)
  print("\n" * 10)


  try:
    thr = threading.Thread(target=forwarder_thread, args=(data,))
    thr.start()
    print("Django: Started communicator thread")

  except Exception as e:
    print("Django: exception starting communicator thread:", e)

  return HttpResponseRedirect(reverse('home'))


def sign_out(request):
  # Clear out the user and token
  remove_user_and_token(request)

  return HttpResponseRedirect(reverse('home'))


def get_token(request):
  sys.exit(0)
