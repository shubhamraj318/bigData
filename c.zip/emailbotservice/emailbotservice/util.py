import datetime


def log(*args, **kwargs):
    _args = [f"{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')}:"] + list(args)
    print(*_args, **kwargs)