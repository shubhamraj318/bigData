from django.contrib import admin
from django.urls import path, include
from helper import views

urlpatterns = [
    path('', include('helper.urls')),
    path('admin/', admin.site.urls),
]