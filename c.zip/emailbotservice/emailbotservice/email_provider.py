import os
import datetime
from .util import log
from .bot_config import EmailBotConfig, ConnectConfig


class Handle():

    def __init__(self, private_obj):
        self._private_obj = private_obj

    @property
    def private_obj(self):
        return self._private_obj


class RunStatus(dict):

    @property
    def last_timestamp(self):
        return self.get("last_timestamp")

    @property
    def last_processed_email(self):
        return self.get("last_processed_email")


class EmailFilter(dict):

    @property
    def last_timestamp(self):
        return self.get("last_timestamp")

    @property
    def last_processed_email(self):
        return self.get("last_processed_email")


class Attachment():

    def __init__(self, filename, filesize, content_type, filepath=None, payload=None):
        self._filename = filename
        self._filepath = filepath
        self._filesize = filesize
        self._content_type = content_type
        self._payload = payload

    @property
    def filename(self):
        return self._filename

    @property
    def filepath(self):
        return self._filepath

    @filepath.setter
    def filepath(self, fp):
        if os.path.isfile(fp):
            self._filepath = fp

    @property
    def filesize(self):
        return self._filesize

    @property
    def content_type(self):
        return self._content_type

    @property
    def payload(self):
        return self._payload


class EmailProvider():

    def __init__(self, bot_config: EmailBotConfig, save_callback=None, fetched_callback=None):
        self._bot_config = bot_config
        self._save_callback = save_callback
        self._fetched_callback = fetched_callback

    @property
    def bot_config(self):
        return self._bot_config

    @property
    def save_callback(self):
        return self._save_callback

    @property
    def fetched_callback(self):
        return self._fetched_callback

    def log(self, *args, **kwargs):
        if self.bot_config:
            arg = [f"Bot: {self.bot_config.name}:"]
        else:
            arg = []

        _args = arg + list(args)
        return log(*_args, **kwargs)

    def get_connect_config(self, bot_config: EmailBotConfig, bot_status: RunStatus):
        raise NotImplementedError

    def connect(self, connect_config:ConnectConfig=None):
        raise NotImplementedError

    def fetch_mails(self, handle:Handle, conenct_config:ConnectConfig=None, email_filter:EmailFilter=None):
        raise NotImplementedError

    def fetch_attachment(self, handle:Handle, attachment_identifier, conenct_config:ConnectConfig=None):
        raise NotImplementedError

    def parse_timestamp(self, timestamp_str):

        supported_formats = [
            '%a, %d %b %Y %H:%M:%S %Z',
            '%a, %d %b %Y %H:%M:%S %z',
            "%Y-%m-%dT%H:%M:%SZ",
        ]

        if timestamp_str.strip().endswith(")"):
            idx = timestamp_str.rfind("(")
            mod_timestamp_str = timestamp_str[0:idx].strip()
            try:
                timestamp = self.parse_timestamp(mod_timestamp_str)
                return timestamp
            except:
                pass

        for f in supported_formats:
            try:
                timestamp = datetime.datetime.strptime(timestamp_str, f)
                return timestamp
            except ValueError:
                continue

        return None

    def issue_fetched_callback(self, attachment:Attachment, file_id):
        if self.fetched_callback:
            try:
                self._fetched_callback(file_id)
                log_fmt = "Fetched callback done: FileId = {file_id}, Type: {content_type} Size: {filesize} Name: {filename} FilePath: {filepath}"
                self.log(log_fmt.format(
                    file_id=file_id,
                    content_type=attachment.content_type,
                    filesize=attachment.filesize,
                    filename=attachment.filename,
                    filepath=attachment.filepath,
                ))
                return True
            except Exception as e:
                log_fmt = "{error} FileId = {file_id}, Type: {content_type} Size: {filesize} Name: {filename} FilePath: {filepath}"
                self.log(log_fmt.format(
                    error=f"Fetched callback exception: {type(e)}: {e}",
                    file_id=file_id,
                    content_type=attachment.content_type,
                    filesize=attachment.filesize,
                    filename=attachment.filename,
                    filepath=attachment.filepath,
                ))
        return False

    def issue_save_callback(self, attachment:Attachment):
        if self.save_callback:
            file_id = ""
            try:
                file_id = self._save_callback(attachment)
                log_fmt = "Saved attachment: FileId = {file_id}, Type: {content_type} Size: {filesize} Name: {filename} FilePath: {filepath}"
                self.log(log_fmt.format(
                    file_id=file_id,
                    content_type=attachment.content_type,
                    filesize=attachment.filesize,
                    filename=attachment.filename,
                    filepath=attachment.filepath,
                ))
                return file_id
            except Exception as e:
                log_fmt = "{error} FileId = {file_id}, Type: {content_type} Size: {filesize} Name: {filename} FilePath: {filepath}"
                self.log(log_fmt.format(
                    error=f"Exception saving attachment: {type(e)}: {e}",
                    file_id=file_id,
                    content_type=attachment.content_type,
                    filesize=attachment.filesize,
                    filename=attachment.filename,
                    filepath=attachment.filepath,
                ))
        return None


class DummyEmailProvider(EmailProvider):

    def __init__(self):
        super().__init__()

    def connect(self, connect_config):
        return None

    def fetch_mails(self, handle, conenct_config, filter):
        return []

    def fetch_attachment(self, handle, conenct_config, attachment_identifier):
        raise PermissionError()

    def get_connect_config(self, bot_config: EmailBotConfig, bot_status: RunStatus):
        raise NotImplementedError