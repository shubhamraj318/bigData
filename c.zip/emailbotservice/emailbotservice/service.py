import os
import sys
import json
import asyncio
import functools

from.util import log
from .email_provider import RunStatus, Attachment
from .bot_config import get_email_bot_config, EmailBotConfig
from .doc_import_bot_factory import DocImportBotFactory


class BotStatusDb():

    def __init__(self, db_file):
        self._db_file = db_file
        if not os.path.isfile(self._db_file):
            with open(self._db_file, "w", encoding="utf-8") as fd:
                json.dump({}, fd)

    @property
    def db(self):
        try:
            with open(self._db_file, encoding="utf-8") as fd:
                db = json.load(fd)
                return db
        except Exception:
            return {}

    async def get(self, db_key):
        db = self.db
        if db_key in db:
            return db[db_key]
        return {}

    async def update(self, db_key, db_config):
        db = self.db
        db[db_key] = db_config
        with open(self._db_file, "w", encoding="utf-8") as fd:
            json.dump(db, fd)


class EmailBotService():

    def __init__(self, loop, interval, db_file, attachment_directory, pickles_directory):
        self._loop = loop
        self._interval = interval
        self._db_file = db_file
        self._configs = {}
        self._bots = {}

        if os.path.exists(attachment_directory) and os.path.isdir(attachment_directory):
            self.log(f"Using attachment directory: {os.path.realpath(attachment_directory)}")
        else:
            self.log(f"Creating attachment directory: {os.path.realpath(attachment_directory)}")
            os.makedirs(os.path.realpath(attachment_directory))

        if os.path.exists(pickles_directory) and os.path.isdir(pickles_directory):
            self.log(f"Using pickles directory: {os.path.realpath(pickles_directory)}")
        else:
            self.log(f"Creating pickles directory: {os.path.realpath(pickles_directory)}")
            os.makedirs(os.path.realpath(pickles_directory))

        self._bot_status_db = BotStatusDb(db_file)
        self._attachment_directory = os.path.realpath(attachment_directory)
        self._pickles_directory = os.path.realpath(pickles_directory)

    def log(self, *args, **kwargs):
        arg = [f"EmailBotService:"]
        _args = arg + list(args)
        return log(*_args, **kwargs)

    @property
    def loop(self):
        return self._loop

    @property
    def interval(self):
        return self._interval

    @property
    def attachment_directory(self):
        return self._attachment_directory

    @property
    def pickles_directory(self):
        return self._pickles_directory

    def db_key(self, bot_config):
        return bot_config.server + ":" + bot_config.username

    def add_account(self, account_config):

        if account_config.name in self._configs:
            return False, "Bot already configured"
        self._configs[account_config.name] = account_config
        return True, None

    def save_callback(self, attchment: Attachment, config: EmailBotConfig):

        chars_to_replace = ":@"

        stage = 0
        while True:
            if stage == 0:
                bot_dir = config.account_type
            elif stage == 1:
                bot_dir = os.path.join(bot_dir, config.username)

            for c in chars_to_replace:
                bot_dir = bot_dir.replace(c, "__")

            att_dir = os.path.join(self.attachment_directory, bot_dir)
            if not os.path.exists(att_dir):
                os.makedirs(att_dir)

            stage += 1

            if stage > 1:
                break

        target_file = os.path.join(att_dir, attchment.filename)

        with open(target_file, "wb") as binary_file:
            binary_file.write(attchment.payload)

        attchment.filepath = target_file
        return target_file

    def fetched_callback_handler(self, file_id):
        return True

    async def bot_task(self, config):

        status, error = self.add_account(config)
        if status:
            self.log(f"Added bot config: {config.name}")
        else:
            self.log(f"Adding bot {config.name} config failed. Reason: {error}")
            return

        save_callback = functools.partial(self.save_callback, config=config)

        bot = DocImportBotFactory.get_doc_import_bot(config, save_callback=save_callback)

        bot_run_status = await self.get_bot_status(config)
        # del bot_run_status['last_processed_email']
        fetched_callback_handler = self.fetched_callback_handler

        while True:
            new_status, file_ids = bot.import_documents(bot_run_status, fetched_callback_handler)

            try:
                await self.update_bot_status(config, new_status)
            except Exception as e:
                self.log(f"Exception updating bot status: {type(e)}: {e}")
            print("\n\n")

            await asyncio.sleep(config.interval)

    async def get_bot_status(self, config):
        db_key = self.db_key(config)
        db_config = await self._bot_status_db.get(db_key)
        return RunStatus(
            last_timestamp=db_config.get('LAST_TIMESTAMP'),
            last_processed_email=db_config.get('LAST_PROCESSED_EMAIL')
        )

    async def update_bot_status(self, config, new_status):
        if new_status:
            last_timestamp = new_status.get("last_timestamp")
            last_processed_email = new_status.get("last_processed_email")
            db_key = self.db_key(config)
            db_config = await self._bot_status_db.get(db_key)
            if not db_config:
                db_config = dict(SERVER=config.server, EMAIL_ID=config.username)
            db_config['LAST_TIMESTAMP'] = last_timestamp
            db_config['LAST_PROCESSED_EMAIL'] = last_processed_email

            await self._bot_status_db.update(db_key, db_config)

        return True

    def run(self, config_json):

        try:

            with open(config_json, encoding="utf-8") as fd:
                config = json.load(fd)

            print(f"Config: {config}")
            accounts = config.get("accounts", [])

        except Exception as e:
            self.log(f"Exception reading json config: {type(e)}: {e}")
            return

        configs = []
        for account in accounts:
            bot_config = get_email_bot_config(account)
            if bot_config:
                bot_config.set_global("pickles_directory", self.pickles_directory)
                configs.append(bot_config)

        if not configs:
            self.log(f"No configs available. Stopiing")
        else:

            async def dummy_task():
                while True:
                    await asyncio.sleep(1)

            for config in configs:
                self.loop.create_task(self.bot_task(config))

            while True:
                try:
                    self.loop.run_until_complete(dummy_task())
                except KeyboardInterrupt:
                    self.log(f"Interrupted. Stopping")
                    sys.exit(0)
                except Exception as e:
                    continue

