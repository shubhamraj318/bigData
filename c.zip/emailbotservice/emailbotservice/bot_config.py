import os
import base64
import pwinput
from .util import log as util_log


def log(*args, **kwargs):
    arg = [f"BotConfig:"]
    _args = arg + list(args)
    return util_log(*_args, **kwargs)


BOT_TYPE_EMAIL = 'email'


ACCOUNT_TYPE_IMAP = 'imap'
ACCOUNT_TYPE_GMAIL = 'gmail'
ACCOUNT_TYPE_OUTLOOK = 'outlook'
ACCOUNT_TYPE_DUMMY = 'dummy'


class BotConfig():

    def __init__(self, bot_type):
        self._bot_type = bot_type
        self._globals = {}

    @property
    def bot_type(self):
        return self._bot_type

    def get_global(self, name):
        return self._globals.get(name)

    def set_global(self, name, value):
        if value is None:
            del self._globals[name]
        else:
            self._globals[name] = value

    @staticmethod
    def encode(plain):
        return base64.b64encode(plain.encode()).decode()

    @staticmethod
    def decode(encrypted):
        return base64.b64decode(encrypted.encode()).decode()



class EmailBotConfig(BotConfig):

    def __init__(self, name, account_type, username, interval, server=None, password=None, auth_file=None, mail_folder='INBOX'):

        if account_type == ACCOUNT_TYPE_IMAP:
            if not server or not password:
                raise ValueError("IMAP account needs server and password")
        elif account_type == ACCOUNT_TYPE_GMAIL:
            if not auth_file or not os.path.isfile(auth_file):
                raise ValueError("GMAIL account needs auth file")
        elif account_type == ACCOUNT_TYPE_OUTLOOK:
            if not auth_file or not os.path.isfile(auth_file):
                raise ValueError("OUTLOOK account needs auth file")
        else:
            raise ValueError(f"Invalid account type: {account_type}")

        super().__init__(BOT_TYPE_EMAIL)

        self._name = name
        self._account_type = account_type
        self._server = server
        self._username = username
        self._password = password
        self._auth_file = auth_file
        self._interval = interval
        self._mail_folder = mail_folder
        self._calculated_server = None

    @property
    def name(self):
        return self._name

    @property
    def account_type(self):
        return self._account_type

    @property
    def server(self):

        if self._account_type == ACCOUNT_TYPE_GMAIL:
            if not self._calculated_server:
                try:
                    self._calculated_server = self.username.split("@")[-1]
                except:
                    self._calculated_server = 'gmail.com'

            return self._calculated_server

        elif self._account_type == ACCOUNT_TYPE_OUTLOOK:
            if not self._calculated_server:
                try:
                    self._calculated_server = self.username.split("@")[-1]
                except:
                    self._calculated_server = 'outlook.com'

            return self._calculated_server

        return self._server

    @property
    def username(self):
        return BotConfig.decode(self._username)

    @property
    def password(self):
        return BotConfig.decode(self._password)

    @property
    def auth_file(self):
        return self._auth_file

    @property
    def interval(self):
        return self._interval

    @property
    def mail_folder(self):
        return self._mail_folder


class ConnectConfig():
    pass


def get_email_bot_config(bot_dict):

    name = None
    bot_config = None
    account = bot_dict

    try:
        account_type = account.get("account_type")
        if not account_type:
            log(f"Account config missing account_type: {account}")
            return bot_config

        name = account.get("name")
        if not name:
            log(f"Account config missing name: {account}")
            return bot_config

        username = account.get("username")
        if not username:
            log(f"Account config missing username: {account}")
            return bot_config

        interval = account.get("polling_interval")
        if not interval:
            log(f"Account config missing interval: {account}. Using default: {default_interval}")
        else:
            interval *= 60

        if account_type == ACCOUNT_TYPE_IMAP:

            server = account.get("server")
            if not server:
                log(f"Account config missing server: {account}")
                return bot_config

            password = account.get("password")
            if not password:
                log(f"Account config missing password: {account}. Need to input")
                _password = pwinput.pwinput(prompt=f"Password for {BotConfig.decode(username)}: ")
                password = BotConfig.encode(_password)

            bot_config = EmailBotConfig(
                name=name, account_type=account_type, server=server,
                username=username, password=password, interval=interval
            )
        elif account_type == ACCOUNT_TYPE_GMAIL:

            auth_file = account.get("credentials_file")
            if not auth_file:
                log(f"Account config missing auth_file: {account}. Need to input")
                auth_file = pwinput.pwinput(prompt=f"JSON file: ")

            bot_config = EmailBotConfig(
                name=name, account_type=account_type,
                username=username, auth_file=auth_file, interval=interval
            )
        elif account_type == ACCOUNT_TYPE_OUTLOOK:

            auth_file = account.get("credentials_file")
            if not auth_file:
                log(f"Account config missing auth_file: {account}. Need to input")
                auth_file = pwinput.pwinput(prompt=f"YAML file: ")

            bot_config = EmailBotConfig(
                name=name, account_type=account_type,
                username=username, auth_file=auth_file, interval=interval
            )
    except Exception as e:
        botname = f"{name}: " if name else ""
        log(f"{botname}Exception processing json config: {type(e)}: {e}")

    return bot_config
