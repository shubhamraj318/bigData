import requests
import json

graph_url = 'https://graph.microsoft.com/v1.0'

def get_user(token):
  # Send GET to /me
  user = requests.get(
    '{0}/me'.format(graph_url),
    headers={
      'Authorization': 'Bearer {0}'.format(token)
    },
    params={
      '$select': 'displayName,mail,mailboxSettings,userPrincipalName'
    })
  # Return the JSON result
  return user.json()

"""
def get_mails(token):
  # 'https://graph.microsoft.com/v1.0/users/8417e77c-d646-483d-a9b6-8a711266d94e/messages?$select=sender,subject'
  mails = requests.get(
    '{0}/me/messages'.format(graph_url),
    headers={
      'Authorization': 'Bearer {0}'.format(token)
    },
    params={
      '$select': 'sender,subject'
    })
  # Return the JSON result
  return mails.json()
  """

"""
def get_mails(token):
  # 'https://graph.microsoft.com/v1.0/users/8417e77c-d646-483d-a9b6-8a711266d94e/messages?$select=sender,subject'
  mails = requests.get(
    '{0}/me/mailfolders/inbox/messages'.format(graph_url),
    headers={
      'Authorization': 'Bearer {0}'.format(token)
    },
    params={
    })
  # Return the JSON result
  return mails.json()
  """

def get_mails(token):
  # 'https://graph.microsoft.com/v1.0/users/8417e77c-d646-483d-a9b6-8a711266d94e/messages?$select=sender,subject'
  mails = requests.get(
    '{0}/me/mailfolders/inbox/messages'.format(graph_url),
    headers={
      'Authorization': 'Bearer {0}'.format(token)
    },
    params={
      '$top': '1000'
    })
  # Return the JSON result
  return mails.json()