from .doc_import_bot import DocImportBot
from .email_provider import EmailFilter, RunStatus
from .bot_config import EmailBotConfig, ConnectConfig
from .email_provider_factory import EmailProviderFactory


class EmailDocImportBot(DocImportBot):

    def __init__(self, bot_config: EmailBotConfig, save_callback=None):
        super().__init__(bot_config, save_callback=save_callback)

    def import_documents(self, bot_run_status: RunStatus,
                         fetched_callback_handler, connect_config: ConnectConfig=None, save_callback=None):

        email_filter = None

        self._provider = EmailProviderFactory.get_email_provider(
            self.bot_config,
            save_callback=self.save_callback,
            fetched_callback=fetched_callback_handler
        )

        connect_config = self.provider.get_connect_config(self.bot_config, bot_run_status)

        handle = self.provider.connect(connect_config)

        if bot_run_status:
            email_filter = EmailFilter(
                last_timestamp=bot_run_status.last_timestamp,
                last_processed_email=bot_run_status.last_processed_email
            )

        new_status, file_ids = self.provider.fetch_mails(handle, connect_config, email_filter)
        return new_status, file_ids

    def test_connection(connect_config: ConnectConfig=None):
        handle = self.provider.connect(connect_config)
        return handle