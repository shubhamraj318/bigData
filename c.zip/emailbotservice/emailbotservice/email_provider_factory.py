from .email_provider import DummyEmailProvider
from .imap_email_provider import IMAPEmailProvider
from .google_email_provider import GoogleEmailProvider
from .outlook_email_provider import OutlookEmailProvider


from .bot_config import BotConfig, ACCOUNT_TYPE_IMAP, ACCOUNT_TYPE_GMAIL, ACCOUNT_TYPE_OUTLOOK, ACCOUNT_TYPE_DUMMY


class EmailProviderFactory():

    @staticmethod
    def get_email_provider(bot_config: BotConfig, save_callback=None, fetched_callback=None):
        if bot_config.account_type == ACCOUNT_TYPE_IMAP:
            return IMAPEmailProvider(bot_config, save_callback=save_callback, fetched_callback=fetched_callback)
        elif bot_config.account_type == ACCOUNT_TYPE_GMAIL:
            return GoogleEmailProvider(bot_config, save_callback=save_callback, fetched_callback=fetched_callback)
        elif bot_config.account_type == ACCOUNT_TYPE_OUTLOOK:
            return OutlookEmailProvider(bot_config, save_callback=save_callback, fetched_callback=fetched_callback)
        elif bot_config.account_type == ACCOUNT_TYPE_DUMMY:
            return DummyEmailProvider(bot_config, save_callback=save_callback, fetched_callback=fetched_callback)
        else:
            raise ValueError(f"Invalid account type: {bot_config.account_type}")