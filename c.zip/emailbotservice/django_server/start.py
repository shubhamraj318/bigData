import os
import sys
import time
import asyncio

LOCAL_SERVER_PORT = 9876

import psutil
from subprocess import Popen, PIPE

import socket
import threading



class ThreadedServer(object):

    def __init__(self, host, port, event):
        self.host = host
        self.port = port
        self.event = event
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.settimeout(60)
        self.sock.bind((self.host, self.port))
        self._need_to_stop = False
        self.data = None

    def stop(self):
        self._need_to_stop = True

    def start(self):
        thr = threading.Thread(target=self.listen)
        thr.start()

    def listen(self):
        self.sock.listen(1)
        while not self._need_to_stop:
            try:
                client, address = self.sock.accept()
                client.settimeout(10)

                size = 10240
                try:
                    data = client.recv(size)
                    if data:
                        self.data = data.decode()
                        self.event.set()
                        client.send("ok".encode())
                        time.sleep(1)
                except:
                    pass
                finally:
                    client.close()

            except socket.timeout:
                try:
                    client.close()
                except:
                    pass

        print("Listener exited")


def start_django_server(yaml_file=""):

    """
    filename = __file__
    manager = filename.replace("start.py", "manage.py")
    p = Popen(f'python {manager} runserver', shell=False)
    print("Started django server with pid:", p.pid)

    """

    filename = __file__
    manager = filename.replace("start.py", "start_django.py")


    DETACHED_PROCESS = 0x00000008
    CREATE_NEW_PROCESS_GROUP = 0x00000200

    my_env = os.environ.copy()
    my_env["OUTLOOK_YAML_FILE"] = yaml_file

    p = Popen(
        ["python", manager],
        shell=True, stdin=PIPE, stdout=PIPE, stderr=PIPE,
        creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
        env=my_env
    )


def start_response_collector(event):
    srv = ThreadedServer("localhost", LOCAL_SERVER_PORT, event)
    srv.start()
    return srv

from multiprocessing import Process


def collect_auth_data(yaml_file=""):

    data = None

    ev = threading.Event()
    srv = start_response_collector(ev)
    start_django_server(yaml_file)

    # p = Process(target=start_django_server, args=())
    # p.start()


    while True:
        ev.wait(10)
        if srv.data:
            data = srv.data
            srv.stop()
            break

    """
    try:
        p.terminate()
    except Exception as e:
        pass

    try:
        p.kill()
    except Exception as e:
        pass
    """

    return data


async def get_auth_data(yaml_file="", timeout=300):
    loop = asyncio.get_running_loop()
    executor = None
    try:
        return await asyncio.wait_for(
            loop.run_in_executor(executor, collect_auth_data, yaml_file), timeout
        )
    except asyncio.TimeoutError:
        print("get_auth_data: Timed out")
        return None



if __name__ == '__main__':

    loop = asyncio.get_event_loop()
    data = loop.run_until_complete(get_auth_data())

    # data = collect_auth_data()
    print("Data:", data)

    while True:
        time.sleep(5)

