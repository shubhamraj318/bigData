from .bot_config import EmailBotConfig
from .email_doc_import_bot import EmailDocImportBot


class EmailDocImportBotFactory():

    @staticmethod
    def get_doc_import_bot(bot_config:EmailBotConfig, save_callback=None):
        return EmailDocImportBot(bot_config, save_callback=save_callback)
