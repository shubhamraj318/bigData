
import os
import sys
import time
from subprocess import Popen, PIPE


def start():

    exe = "python"

    filename = __file__
    script = filename.replace("start_django.py", "manage.py")
    param = "runserver"


    DETACHED_PROCESS = 0x00000008
    CREATE_NEW_PROCESS_GROUP = 0x00000200


    p = Popen([exe, script, param], shell=False)
    print("Started django server with pid:", p.pid)


if __name__ == '__main__':
    start()
    print("==================Started==================")
    print(os.environ)
    time.sleep(300)
    print("==================Sleeping Over==================")
    sys.exit(0)
