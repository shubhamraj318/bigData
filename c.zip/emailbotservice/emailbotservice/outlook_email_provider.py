import os
import pickle
import base64
import datetime
import requests

from .bot_config import EmailBotConfig, ConnectConfig
from .email_provider import EmailProvider, Handle, RunStatus, EmailFilter, Attachment

from django_server.start import collect_auth_data


class OutlookEmailConnectConfig(ConnectConfig):

    def __init__(self, pickle_directory):
        self._pickle_directory = pickle_directory

    @property
    def pickle_directory(self):
        return self._pickle_directory


class OutlookEmailProvider(EmailProvider):

    def __init__(self, bot_config: EmailBotConfig, save_callback=None, fetched_callback=None):
        self._token_value = None
        self._calculated_server = None
        super().__init__(bot_config, save_callback=save_callback, fetched_callback=fetched_callback)

    def get_connect_config(self, bot_config: EmailBotConfig, bot_status: RunStatus) -> OutlookEmailConnectConfig:
        pickle_dir = bot_config.get_global("pickles_directory")
        return OutlookEmailConnectConfig(pickle_directory=pickle_dir)

    def get_token_value(self):

        print("\n" * 10)
        self.log(f"Sign in on:", "http://127.0.0.1:8000/")
        print("\n" * 10)

        return collect_auth_data(os.path.realpath(self.bot_config.auth_file))

    def get_mail_test(self):
        graph_url = 'https://graph.microsoft.com/v1.0'
        mails = requests.get(
            '{0}/me/mailfolders/inbox/messages'.format(graph_url),
            headers={
            'Authorization': 'Bearer {0}'.format(self._token_value)
            },
            params={
            '$top': '1'
            })
        return mails.json()

    def connect(self, connect_config: OutlookEmailConnectConfig=None) -> Handle:

        self._token_value = None
        pickle_file_name = f"{os.path.basename(self.bot_config.auth_file)}.pickle"

        if not connect_config or not connect_config.pickle_directory:
            raise ValueError("Invalid connect config")

        pickle_file = os.path.join(connect_config.pickle_directory, pickle_file_name)

        if os.path.isfile(pickle_file):
            try:
                with open(pickle_file, 'rb') as token:
                    self._token_value = pickle.load(token)
            except Exception:
                self._token_value = None

        if self._token_value:

            print("\n" * 10)
            print("Token:", type(self._token_value), self._token_value)
            print("\n" * 10)

            try:
                one_mail = self.get_mail_test()
                print("Mails:",  one_mail)
                if "error" in one_mail:
                    self._token_value = None
            except Exception as e:
                self._token_value = None

        if not self._token_value:

            self._token_value = self.get_token_value()

            with open(pickle_file, 'wb') as token:
                pickle.dump(self._token_value, token)

        handle_dict = {
            "token_value": self._token_value
        }

        return Handle(handle_dict)

    def get_attchments(self, mail_id):
        graph_url = 'https://graph.microsoft.com/v1.0'
        # /me/messages/{id}/attachments
        atts = requests.get('{0}/me/messages/{1}/attachments'.format(graph_url, mail_id),
            headers={
                'Authorization': 'Bearer {0}'.format(self._token_value)
            }
        )

        if "error" in atts:
            data = []
        else:
            data = atts.json()['value']
        return data


    def fetch_mails(self, handle: Handle, connect_config:ConnectConfig=None, email_filter: EmailFilter=None):

        reverse = True
        attachments = []
        file_ids = []
        graph_url = 'https://graph.microsoft.com/v1.0'

        email_filter = email_filter or EmailFilter()

        run_status = RunStatus(
            last_timestamp=email_filter.last_timestamp,
            last_processed_email=email_filter.last_processed_email
        )

        token_value = handle.private_obj.get("token_value")
        if not token_value:
            return run_status, file_ids

        last_timestamp = email_filter.last_timestamp
        last_processed_email = email_filter.last_processed_email

        try:
            mails = requests.get('{0}/me/messages'.format(graph_url),
                headers={
                    'Authorization': 'Bearer {0}'.format(token_value)
                },
                params={
                    '$top': '1000'
                })

            if "error" in mails:
                messages = []
            else:
                messages = mails.json()['value']

        except Exception as e:
            self.log(f"Exception fetching emails: {type(e)}: {e}")
            return run_status, file_ids

        if not last_timestamp and not last_processed_email:
            messages.reverse()

        latest_email = None

        for msg in messages:
            try:
                message_id = msg['id']
                subject = msg['subject']
                try:
                    sender = msg['sender']['emailAddress']["address"]
                except:
                    sender = str(msg['sender'])

                date = msg['receivedDateTime']

                try:
                    timestamp = self.parse_timestamp(date)
                    timestamp_key = timestamp.isoformat()
                except ValueError as e:
                    self.log(f"Timestamp parse error for: {date}: {type(e)}: {e}")

                self.log(f"Checking mail: \ndated: {date}: \nfrom: {sender}\nsubject: {subject}")

                if message_id == last_processed_email:
                    self.log(f"Reached last processed email. Stopping")
                    return run_status, file_ids

                if last_timestamp:
                    lt = datetime.datetime.fromisoformat(last_timestamp)
                    if not lt.tzname():
                        utc = pytz.UTC
                        lt = utc.localize(lt)

                    if lt >= timestamp:
                        self.log(f"Reached last processed email. Stopping")
                        return run_status, file_ids

                if last_processed_email and not latest_email:
                    latest_email = msg
                    self.log(f"Marking this email as last processed email")
                    run_status = RunStatus(
                        last_timestamp=timestamp_key,
                        last_processed_email=message_id
                    )
                elif not last_processed_email:
                    latest_email = msg
                    self.log(f"Marking this email as last processed email")
                    run_status = RunStatus(
                        last_timestamp=timestamp_key,
                        last_processed_email=message_id
                    )

                if msg['hasAttachments']:
                    atts = self.get_attchments(message_id)

                    for att in atts:
                        name = att['name']
                        size = att['size']
                        contentType = att['contentType']

                        if not name:
                            self.log(f"Attachment without filename. Skipping. Size: {size} content_type: {contentType}")
                            continue

                        payload = base64.b64decode(att['contentBytes'])

                        attachment = Attachment(name, size, contentType, payload=payload)
                        attachments.append(attachment)

                        file_id = self.issue_save_callback(attachment)
                        if file_id is not None:
                            status = self.issue_fetched_callback(attachment, file_id)
                            if status:
                                file_ids.append(file_id)

            except Exception as e:
                self.log(f"Exception processing message: {type(e)}: {e}")

        return run_status, file_ids
