import os
import pickle
import base64
import datetime

from googleapiclient.discovery import build
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow

from .bot_config import EmailBotConfig, ConnectConfig
from .email_provider import EmailProvider, Handle, RunStatus, EmailFilter, Attachment


class GoogleEmailConnectConfig(ConnectConfig):

    def __init__(self, pickle_directory):
        self._pickle_directory = pickle_directory

    @property
    def pickle_directory(self):
        return self._pickle_directory


class GoogleEmailProvider(EmailProvider):

    def __init__(self, bot_config: EmailBotConfig, save_callback=None, fetched_callback=None):
        self._service = None
        self._calculated_server = None
        super().__init__(bot_config, save_callback=save_callback, fetched_callback=fetched_callback)

    def get_connect_config(self, bot_config: EmailBotConfig, bot_status: RunStatus) -> GoogleEmailConnectConfig:
        pickle_dir = bot_config.get_global("pickles_directory")
        return GoogleEmailConnectConfig(pickle_directory=pickle_dir)

    def connect(self, connect_config: GoogleEmailConnectConfig=None) -> Handle:

        SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']
        pickle_file_name = f"{os.path.basename(self.bot_config.auth_file)}.pickle"

        if not connect_config or not connect_config.pickle_directory:
            raise ValueError("Invalid connect config")

        pickle_file = os.path.join(connect_config.pickle_directory, pickle_file_name)

        creds = None

        if os.path.isfile(pickle_file):
            try:
                with open(pickle_file, 'rb') as token:
                    creds = pickle.load(token)
            except Exception:
                creds = None

        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(self.bot_config.auth_file, SCOPES)
                creds = flow.run_local_server(port=0)

            with open(pickle_file, 'wb') as token:
                pickle.dump(creds, token)

        # Connect to the Gmail API
        self._service = build('gmail', 'v1', credentials=creds)

        handle_dict = {
            "service": self._service
        }

        return Handle(handle_dict)

    def fetch_mails(self, handle: Handle, connect_config:ConnectConfig=None, email_filter: EmailFilter=None):

        reverse = True
        attachments = []
        file_ids = []

        email_filter = email_filter or EmailFilter()

        run_status = RunStatus(
            last_timestamp=email_filter.last_timestamp,
            last_processed_email=email_filter.last_processed_email
        )

        service = handle.private_obj.get("service")
        if not service:
            return run_status, file_ids

        last_timestamp = email_filter.last_timestamp
        last_processed_email = email_filter.last_processed_email

        try:
            result = service.users().messages().list(
                maxResults=500, userId='me',
                labelIds=["INBOX"], includeSpamTrash=False
            ).execute()

            messages = result.get("messages")
        except Exception as e:
            self.log(f"Exception fetching emails: {type(e)}: {e}")
            return run_status, file_ids

        if not last_timestamp and not last_processed_email:
            messages.reverse()

        latest_email = None

        for msg in messages:
            try:
                message_id = msg['id']

                txt = self._service.users().messages().get(userId='me', id=message_id).execute()
                payload = txt['payload']
                headers = payload['headers']

                subject = None
                sender = None
                date = None

                # Look for Subject and Sender Email in the headers
                for d in headers:
                    if d['name'] == 'Subject':
                        subject = d['value']
                    if d['name'] == 'From':
                        sender = d['value']
                    if d['name'] == 'Date':
                        date = d['value']

                if not all([subject, sender, date]):
                    self.log(f"Error: Not all fields obtained: [subject, sender, date]:", [subject, sender, date])
                    continue

                try:
                    timestamp = self.parse_timestamp(date)
                    timestamp_key = timestamp.isoformat()
                except ValueError as e:
                    self.log(f"Timestamp parse error for: {date}: {type(e)}: {e}")

                self.log(f"Checking mail: \ndated: {date}: \nfrom: {sender}\nsubject: {subject}")

                if message_id == last_processed_email:
                    self.log(f"Reached last processed email. Stopping")
                    return run_status, file_ids

                if last_timestamp:
                    lt = datetime.datetime.fromisoformat(last_timestamp)
                    if not lt.tzname():
                        utc = pytz.UTC
                        lt = utc.localize(lt)

                    if lt >= timestamp:
                        self.log(f"Reached last processed email. Stopping")
                        return run_status, file_ids

                if last_processed_email and not latest_email:
                    latest_email = msg
                    self.log(f"Marking this email as last processed email")
                    run_status = RunStatus(
                        last_timestamp=timestamp_key,
                        last_processed_email=message_id
                    )
                elif not last_processed_email:
                    latest_email = msg
                    self.log(f"Marking this email as last processed email")
                    run_status = RunStatus(
                        last_timestamp=timestamp_key,
                        last_processed_email=message_id
                    )

                for part in payload.get('parts', ''):
                    if part['filename']:
                        if 'data' in part['body']:
                            data = part['body']['data']
                        else:
                            att_id = part['body']['attachmentId']
                            att = self._service.users().messages().attachments().get(
                                userId='me', messageId=message_id, id=att_id).execute()
                            data = att['data']
                            file_data = base64.urlsafe_b64decode(data.encode('UTF-8'))

                            if not part['filename']:
                                self.log(f"Attachment without filename. Skipping. Size: {att['size']} content_type: {part['mimeType']}")
                                continue

                            attachment = Attachment(part['filename'], att['size'], part['mimeType'], payload=file_data)
                            attachments.append(attachment)

                            file_id = self.issue_save_callback(attachment)
                            if file_id is not None:
                                status = self.issue_fetched_callback(attachment, file_id)
                                if status:
                                    file_ids.append(file_id)

            except Exception as e:
                self.log(f"Exception processing message: {type(e)}: {e}")

        return run_status, file_ids
