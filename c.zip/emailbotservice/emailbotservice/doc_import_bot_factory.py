from .bot_config import BotConfig, BOT_TYPE_EMAIL
from .email_doc_import_bot_factory import EmailDocImportBotFactory



class DocImportBotFactory():

    @staticmethod
    def get_doc_import_bot(bot_config:BotConfig, save_callback=None):
        if bot_config.bot_type == BOT_TYPE_EMAIL:
            return EmailDocImportBotFactory.get_doc_import_bot(bot_config, save_callback=save_callback)
        else:
            raise ValueError(f"Invalid bot type: {bot_config.bot_type}")