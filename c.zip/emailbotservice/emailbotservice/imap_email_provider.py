import pytz
import datetime
from base64 import b64encode
from imap_tools import MailBox

from .bot_config import ConnectConfig, EmailBotConfig
from .email_provider import EmailProvider, Handle, RunStatus, EmailFilter, Attachment


class IMAPEmailConnectConfig(ConnectConfig):
    pass


class IMAPEmailProvider(EmailProvider):

    def __init__(self, bot_config: EmailBotConfig, save_callback=None, fetched_callback=None):
        super().__init__(bot_config, save_callback=save_callback, fetched_callback=fetched_callback)
        self._mailbox = None

    @property
    def mailbox(self):
        return self._mailbox

    def get_connect_config(self, bot_config: EmailBotConfig, bot_status: RunStatus):
        return IMAPEmailConnectConfig()

    def connect(self, connect_config: IMAPEmailConnectConfig=None) -> Handle:

        try:
            self._mailbox = MailBox(self.bot_config.server).login(
                self.bot_config.username,
                self.bot_config.password,
                self.bot_config.mail_folder
            )
        except Exception as e:
            self._mailbox = None
            self.log(f"Exception connecting mailbox: {type(e)}: {e}")

        handle_dict = {
            "mailbox": self._mailbox
        }

        return Handle(handle_dict)


    def fetch_mails(self, handle: Handle, connect_config:ConnectConfig=None, email_filter: EmailFilter=None):

        reverse = True
        attachments = []
        file_ids = []

        email_filter = email_filter or EmailFilter()

        run_status = RunStatus(
            last_timestamp=email_filter.last_timestamp,
            last_processed_email=email_filter.last_processed_email
        )

        mailbox = handle.private_obj.get("mailbox")
        if not mailbox:
            return run_status, file_ids

        last_timestamp = email_filter.last_timestamp
        last_processed_email = email_filter.last_processed_email

        if not last_timestamp and not last_processed_email:
            reverse = False

        try:
            messages = self._mailbox.fetch(reverse=reverse)
        except Exception as e:
            self.log(f"Exception fetching emails: {type(e)}: {e}")
            return run_status, file_ids

        latest_email = None

        for msg in messages:

            self.log(f"Checking mail: \ndated: {msg.date_str}: \nfrom: {msg.from_}\nsubject: {msg.subject}")

            size_key = b64encode(str(msg.size).encode("utf-8")).decode()
            time_key = b64encode(str(msg.date_str).encode("utf-8")).decode()
            subject_key = b64encode(str(msg.subject).encode("utf-8")).decode()

            email_id_key = ":".join([size_key, time_key, subject_key])

            try:
                timestamp = self.parse_timestamp(msg.date_str)
                timestamp_key = timestamp.isoformat()
            except ValueError as e:
                self.log(f"Timestamp parse error for: {msg.date_str}: {type(e)}: {e}")

            if email_id_key == last_processed_email:
                self.log(f"Reached last processed email. Stopping")
                return run_status, file_ids

            if last_timestamp:
                lt = datetime.datetime.fromisoformat(last_timestamp)
                if not lt.tzname():
                    utc = pytz.UTC
                    lt = utc.localize(lt)

                if lt >= timestamp:
                    self.log(f"Reached last processed email. Stopping")
                    return run_status, file_ids

            if reverse and not latest_email:
                latest_email = msg
                run_status = RunStatus(
                    last_timestamp=timestamp_key,
                    last_processed_email=email_id_key
                )
                self.log(f"Marking this email as last processed email")
            elif not reverse:
                latest_email = msg
                run_status = RunStatus(
                    last_timestamp=timestamp_key,
                    last_processed_email=email_id_key
                )
                self.log(f"Marking this email as last processed email")

            if not msg.attachments:
                self.log(f"No attachments")

            for att in msg.attachments:

                filename = att.filename

                filesize = att.size
                content_type = att.content_type
                payload = att.payload

                if not filename:
                    self.log(f"Attachment without filename. Skipping. Size: {filesize} content_type: {content_type}")
                    continue

                attachment = Attachment(filename, filesize, content_type, payload=payload)
                attachments.append(attachment)

                file_id = self.issue_save_callback(attachment)
                if file_id is not None:
                    status = self.issue_fetched_callback(attachment, file_id)
                    if status:
                        file_ids.append(file_id)

        return run_status, file_ids
