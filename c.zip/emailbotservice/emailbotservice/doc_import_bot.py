from .email_provider import RunStatus, EmailProvider
from .bot_config import BotConfig, ConnectConfig

from .email_provider_factory import EmailProviderFactory


class DocImportBot():

    def __init__(self, bot_config: BotConfig, save_callback=None):
        self._provider = None
        self._bot_config = bot_config
        self._save_callback = save_callback

    @property
    def bot_config(self) -> BotConfig:
        return self._bot_config

    @property
    def provider(self) -> EmailProvider:
        return self._provider

    @property
    def save_callback(self):
        return self._save_callback

    def import_documents(self, bot_run_status: RunStatus,
                         fetched_callback_handler, connect_config: ConnectConfig=None, save_callback=None):
        raise NotImplementedError

    def test_connection(connect_config: ConnectConfig=None):
        raise NotImplementedError

